

public class SarcasticQuotes {

	public static void main(String[] args) {
		String quote = "\"Sarcastic quotes\"";
		System.out.println(quote);

	}

}
