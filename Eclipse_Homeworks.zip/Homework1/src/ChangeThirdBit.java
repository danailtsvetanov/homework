
public class ChangeThirdBit {

	public static void main(String[] args) {
		//0 -> 4
		int firstValue = 0;
		int firstValueChanged = (byte) (firstValue | (1 << 2));
		System.out.printf("%d -> %d\n", firstValue, firstValueChanged);
		//8 -> 12
		int secondValue = 8;
		int secondValueChanged = (byte) (secondValue | (1 << 2));
		System.out.printf("%d -> %d\n", secondValue, secondValueChanged);
		//5 -> 1
		int thirdValue = 5;
		int thirdValueChanged = (byte) (thirdValue ^ (1 << 2));
		System.out.printf("%d -> %d\n", thirdValue, thirdValueChanged);
		
	}

}
