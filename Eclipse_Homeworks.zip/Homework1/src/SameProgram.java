//import java.util.Arrays;



public class SameProgram {

	public static void main(String[] args) {
		
		for(String arg : args)
		{
			System.out.print(arg);
		}
		
		//System.out.println(Arrays.toString(args));

	}

}
