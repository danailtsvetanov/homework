
public class CountOctal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int oct = 0377;
		System.out.print(oct);

	}

}
