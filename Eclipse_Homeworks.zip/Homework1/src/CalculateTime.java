import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;




public class CalculateTime {

	public static void main(String[] args) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		CalculateTime calculateTime = new CalculateTime();
		try {
			Date startDate = dateFormat.parse("01/01/1970 00:00:00");
			Date endDate = dateFormat.parse(dateFormat.format(new Date()));
			System.out.printf("Period between %s to %s is ", dateFormat.format(endDate), dateFormat.format(startDate));
			calculateTime.printTimeDifference(startDate, endDate);
		} catch (ParseException e) {
			e.printStackTrace();
		
		}

	}
	public void printTimeDifference(Date startDate, Date endDate){
		
		long difference = endDate.getTime() - startDate.getTime();
		long secondsInMili = 1000;
		long minutesInMili = secondsInMili * 60;
		long hoursInMili = minutesInMili * 60;
		long daysInMili = hoursInMili * 24;
		
		long elapsedDays = difference / daysInMili;
		difference = difference % daysInMili;
		
		long elapsedHours = difference / hoursInMili;
		difference %= hoursInMili;
		
		long elapsedMinutes = difference / minutesInMili;
		difference %= minutesInMili;
		
		long elapsedSeconds = difference / secondsInMili;
		
		System.out.printf("%d Days %d Hours %d Minutes %d Seconds", elapsedDays, elapsedHours, elapsedMinutes, elapsedSeconds);
		
		
	
	}
	
	

}
