
public class CountHexadecimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int hex = 0xFF;
		System.out.println(hex);

	}

}
